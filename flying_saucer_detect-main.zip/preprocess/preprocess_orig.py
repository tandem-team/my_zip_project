import cv2
import numpy as np
import torchvision
# import sys
# sys.path.append("C:\\workroom\\u_workroom\\LSTM_testing_CNNRNN\\flying_saucer\\flying_saucer_detect-main\\classifier")
import sys, os
sys.path.append(os.path.abspath(os.path.join('./', 'classifier')))
print(os.path.abspath(os.path.join('./', 'classifier')))

from classifier import classifier

class Localize:

    def process(self, frame):
        """
        Todo:
        preprocess frame to find out the location of UFO's. 
        sort them from top to bottom based on their location,
        crop the UFO image from original frame and pass it to classifier.
        submit the predicted numbers list.
        """

        ################## Please write your code here ###################


        ##################################################################


        """
        Example: (how to use classifier)

        Note:-
        1. instead of reading cropped image from directory
        you need to find the locations of UFO's on the frame, crop them
        and sort them from top to bottom,
        pass them through classifier and return predicted numbers

        2. This example below is just for demonstration purpose,
        you can delete it when you write your own code above.
        """
        # crop1 = cv2.imread("classifier/numbers/1/1_1.jpg")
        # crop2 = cv2.imread("classifier/numbers/2/2_1.jpg")
        # crop3 = cv2.imread("classifier/numbers/3/3_1.jpg")
        # crop4 = cv2.imread("classifier/numbers/4/4_1.jpg")
        crop_imgs = [crop for crop in frame]

        myanswer = classifier.predict(image=frame)
        return myanswer


localize = Localize()



import cv2, os
from matplotlib import pyplot as plt

im_test_c = cv2.imread(os.path.join("./preprocess", "frame_edited.jpg"))
gray = cv2.imread(os.path.join("./preprocess", "frame_edited.jpg"), cv2.IMREAD_GRAYSCALE)[:450, :]
blurred = cv2.GaussianBlur(gray, (5, 5), 0)
im_test = cv2.Canny(blurred, 50, 200, 255)

thresh1 = cv2.adaptiveThreshold(im_test,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,7,2)

# ret, thresh2 = cv2.threshold(im_test, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
# contours, hierarchy = cv2.findContours(thresh1, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
# image = cv2.drawContours(im_test_c, contours, -1, (0, 255, 0), 2)


params = cv2.SimpleBlobDetector_Params()

# Change thresholds
# params.minThreshold = 10;
# params.maxThreshold = 200;

# Filter by Area.
params.filterByArea = True
params.minArea = 1500

# Filter by Circularity
params.filterByCircularity = False
# params.minCircularity = 0.1

# Filter by Convexity
params.filterByConvexity = True
params.minConvexity = 0.2

# Filter by Inertia
params.filterByInertia = True
params.minInertiaRatio = 0.1

detector = cv2.SimpleBlobDetector_create(params)

keypoints = detector.detect(thresh1)
# im_with_keypoints = cv2.drawKeypoints(im_test_c, keypoints, np.array([]), (0,0,255), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)

(x, y) = keypoints[0].pt
x = int(x)
y = int(y)
# im_with_keypoints = cv2.rectangle(im_test_c, (x-35, y+35), (x+35, y-35), (255, 0, 0), 2)
print(gray.shape)
print(keypoints[0].pt)
print(x, y)
y_diff, x_diff = (80, 80)
plot_pic = im_test_c[y-y_diff:y+y_diff, x-x_diff:x+x_diff]
# plot_pic = cv2.resize(plot_pic, (100,100), interpolation=cv2.INTER_LANCZOS4)
# print(localize.process(gray[y-y_diff:y+y_diff, x-x_diff:x+x_diff]))


from PIL import Image
import pytesseract
im_test_c = Image.fromarray(im_test_c)

print(pytesseract.image_to_string(Image.open("./preprocess/frame_edited.jpg")))

plt.imshow(plot_pic)
print("shape is")
print(plot_pic.shape)
print(plot_pic.dtype)
# transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor(),torchvision.transforms.Normalize((0.1307,), (0.3081,))])


# from PIL import Image
# im_pil = Image.fromarray(plot_pic)
# transform=torchvision.transforms.Compose([
#                               torchvision.transforms.CenterCrop((100, 100)),
#                               torchvision.transforms.ToTensor(),\
#                               torchvision.transforms.Normalize((0.1307,), (0.3081,))])
#
# plot_pic = transform(im_pil).unsqueeze(0)
# print(plot_pic.shape)
plt.show()

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim


class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(1, 10, kernel_size=3)  # 100*100
        self.conv2 = nn.Conv2d(10, 20, kernel_size=3)
        self.conv2_drop = nn.Dropout2d()
        #         self.conv3_drop = nn.Dropout2d()
        self.fc1 = nn.Linear(21 * 21 * 20, 1000)
        #         self.fc2 = nn.Linear(500, 1000)
        self.fc2 = nn.Linear(1000, 10)

    def forward(self, x):
        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2_drop(self.conv2(x)), 2))
        #         x = F.relu(F.max_pool2d(self.conv3_drop(self.conv3(x)), 2))

        x = x.view(-1, 21 * 21 * 20)
        x = F.relu(self.fc1(x))
        x = F.dropout(x, training=self.training)
        x = self.fc2(x)

        return F.log_softmax(x)

# continued_network = Net()
# network_state_dict = torch.load("C:\\workroom\\u_workroom\\LSTM_testing_CNNRNN\\results\\model.pth")
#
# continued_network.load_state_dict(network_state_dict)
#
# continued_network.eval()
# test_loss = 0
# correct = 0
# with torch.no_grad():
#     output = continued_network(plot_pic)
#     pred = output.data.max(1, keepdim=True)
#     print(".........")
#     print(output)
#     print(pred)


